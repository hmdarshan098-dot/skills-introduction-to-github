# CampusNav AI – Full Project Starter

## Features
- Search campus locations
- Filter locations by category
- Interactive map using Leaflet.js and OpenStreetMap
- Location details panel
- Walking-route request through the public OSRM demo service
- Basic keyword-based campus helper (not a generative AI model)
- Python Flask backend and JSON location data

## Important: verify the sample map data
The coordinates in `data/locations.json` are illustrative demo coordinates, NOT confirmed positions of East Point College buildings. Replace them with verified GPS coordinates and update names, descriptions and timings before presenting the map as accurate. Set `verified` to `true` only after checking each location.

## Requirements
- Python 3.10+
- Internet connection for map tiles and the route service
- VS Code (recommended)

## Run on Windows PowerShell
1. Extract the ZIP and open the `CampusNav_AI_Full_Project` folder in VS Code.
2. Open Terminal → New Terminal.
3. Run:
   ```powershell
   py -m venv venv
   .\venv\Scripts\Activate.ps1
   pip install -r requirements.txt
   python app.py
   ```
4. Open `http://127.0.0.1:5000` in your browser.
5. Stop the server with `Ctrl+C`.

If PowerShell blocks activation, run:
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\venv\Scripts\Activate.ps1
```

## Add campus places
Edit `data/locations.json`. Each place has an `id`, `name`, `category`, `description`, `lat`, `lng`, `timings` and `verified` field. Use actual GPS coordinates from the campus. Keep the JSON format valid, save, and refresh the browser.

## How it works
Flask serves the webpage and location data. JavaScript displays the locations with Leaflet. OpenStreetMap supplies map tiles. The route button requests a walking route from the OSRM public demo endpoint. The assistant currently uses simple keyword matching; it is not connected to an AI model.

## Limitations and future work
- Demo coordinates must be replaced with verified campus coordinates.
- Public map/routing services need internet and may have usage limits.
- No login, admin dashboard, indoor positioning or production database is included.
- Future improvements: SQLite database, admin editing, real AI integration through a secure backend, accessible routes, and user testing.

Frontend: HTML, CSS, JavaScript, Leaflet.js
Map data: OpenStreetMap
Backend: Python Flask
Data storage: JSON starter file (SQLite/MySQL can be added later)
