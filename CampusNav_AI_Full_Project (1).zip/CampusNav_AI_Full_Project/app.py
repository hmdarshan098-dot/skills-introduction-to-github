from flask import Flask, jsonify, render_template
import json
from pathlib import Path

app = Flask(__name__)
DATA = Path(__file__).parent / "data" / "locations.json"

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/api/locations")
def locations():
    return jsonify(json.loads(DATA.read_text(encoding="utf-8")))

@app.route("/health")
def health():
    return jsonify({"status": "ok"})

if __name__ == "__main__":
    app.run(debug=True)
